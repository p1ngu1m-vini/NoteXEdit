(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[888],{1118:function(t,e,s){(window.__NEXT_P=window.__NEXT_P||[]).push(["/_app",function(){return s(9479)}])},9479:function(t,e,s){"use strict";let i,r;s.r(e),s.d(e,{default:function(){return tJ}});var a,n=s(5893),o="undefined"==typeof window||"Deno"in globalThis;function u(){}function l(t,e){return"function"==typeof t?t(e):t}function c(t,e){let{type:s="all",exact:i,fetchStatus:r,predicate:a,queryKey:n,stale:o}=t;if(n){if(i){if(e.queryHash!==d(n,e.options))return!1}else if(!f(e.queryKey,n))return!1}if("all"!==s){let t=e.isActive();if("active"===s&&!t||"inactive"===s&&t)return!1}return("boolean"!=typeof o||e.isStale()===o)&&(!r||r===e.state.fetchStatus)&&(!a||!!a(e))}function h(t,e){let{exact:s,status:i,predicate:r,mutationKey:a}=t;if(a){if(!e.options.mutationKey)return!1;if(s){if(p(e.options.mutationKey)!==p(a))return!1}else if(!f(e.options.mutationKey,a))return!1}return(!i||e.state.status===i)&&(!r||!!r(e))}function d(t,e){return(e?.queryKeyHashFn||p)(t)}function p(t){return JSON.stringify(t,(t,e)=>m(e)?Object.keys(e).sort().reduce((t,s)=>(t[s]=e[s],t),{}):e)}function f(t,e){return t===e||typeof t==typeof e&&!!t&&!!e&&"object"==typeof t&&"object"==typeof e&&!Object.keys(e).some(s=>!f(t[s],e[s]))}function y(t){return Array.isArray(t)&&t.length===Object.keys(t).length}function m(t){if(!g(t))return!1;let e=t.constructor;if(void 0===e)return!0;let s=e.prototype;return!!(g(s)&&s.hasOwnProperty("isPrototypeOf"))&&Object.getPrototypeOf(t)===Object.prototype}function g(t){return"[object Object]"===Object.prototype.toString.call(t)}function b(t,e,s=0){let i=[...t,e];return s&&i.length>s?i.slice(1):i}function v(t,e,s=0){let i=[e,...t];return s&&i.length>s?i.slice(0,-1):i}var w=Symbol();function C(t,e){return!t.queryFn&&e?.initialPromise?()=>e.initialPromise:t.queryFn&&t.queryFn!==w?t.queryFn:()=>Promise.reject(Error(`Missing queryFn: '${t.queryHash}'`))}var O=function(){let t=[],e=0,s=t=>{t()},i=t=>{t()},r=t=>setTimeout(t,0),a=i=>{e?t.push(i):r(()=>{s(i)})},n=()=>{let e=t;t=[],e.length&&r(()=>{i(()=>{e.forEach(t=>{s(t)})})})};return{batch:t=>{let s;e++;try{s=t()}finally{--e||n()}return s},batchCalls:t=>(...e)=>{a(()=>{t(...e)})},schedule:a,setNotifyFunction:t=>{s=t},setBatchNotifyFunction:t=>{i=t},setScheduler:t=>{r=t}}}(),x=class{constructor(){this.listeners=new Set,this.subscribe=this.subscribe.bind(this)}subscribe(t){return this.listeners.add(t),this.onSubscribe(),()=>{this.listeners.delete(t),this.onUnsubscribe()}}hasListeners(){return this.listeners.size>0}onSubscribe(){}onUnsubscribe(){}},q=new class extends x{#t;#e;#s;constructor(){super(),this.#s=t=>{if(!o&&window.addEventListener){let e=()=>t();return window.addEventListener("visibilitychange",e,!1),()=>{window.removeEventListener("visibilitychange",e)}}}}onSubscribe(){this.#e||this.setEventListener(this.#s)}onUnsubscribe(){this.hasListeners()||(this.#e?.(),this.#e=void 0)}setEventListener(t){this.#s=t,this.#e?.(),this.#e=t(t=>{"boolean"==typeof t?this.setFocused(t):this.onFocus()})}setFocused(t){this.#t!==t&&(this.#t=t,this.onFocus())}onFocus(){let t=this.isFocused();this.listeners.forEach(e=>{e(t)})}isFocused(){return"boolean"==typeof this.#t?this.#t:globalThis.document?.visibilityState!=="hidden"}},E=new class extends x{#i=!0;#e;#s;constructor(){super(),this.#s=t=>{if(!o&&window.addEventListener){let e=()=>t(!0),s=()=>t(!1);return window.addEventListener("online",e,!1),window.addEventListener("offline",s,!1),()=>{window.removeEventListener("online",e),window.removeEventListener("offline",s)}}}}onSubscribe(){this.#e||this.setEventListener(this.#s)}onUnsubscribe(){this.hasListeners()||(this.#e?.(),this.#e=void 0)}setEventListener(t){this.#s=t,this.#e?.(),this.#e=t(this.setOnline.bind(this))}setOnline(t){this.#i!==t&&(this.#i=t,this.listeners.forEach(e=>{e(t)}))}isOnline(){return this.#i}};function P(t){return Math.min(1e3*2**t,3e4)}function S(t){return(t??"online")!=="online"||E.isOnline()}var F=class extends Error{constructor(t){super("CancelledError"),this.revert=t?.revert,this.silent=t?.silent}};function D(t){return t instanceof F}function A(t){let e,s=!1,i=0,r=!1,a=function(){let t,e;let s=new Promise((s,i)=>{t=s,e=i});function i(t){Object.assign(s,t),delete s.resolve,delete s.reject}return s.status="pending",s.catch(()=>{}),s.resolve=e=>{i({status:"fulfilled",value:e}),t(e)},s.reject=t=>{i({status:"rejected",reason:t}),e(t)},s}(),n=()=>q.isFocused()&&("always"===t.networkMode||E.isOnline())&&t.canRun(),u=()=>S(t.networkMode)&&t.canRun(),l=s=>{r||(r=!0,t.onSuccess?.(s),e?.(),a.resolve(s))},c=s=>{r||(r=!0,t.onError?.(s),e?.(),a.reject(s))},h=()=>new Promise(s=>{e=t=>{(r||n())&&s(t)},t.onPause?.()}).then(()=>{e=void 0,r||t.onContinue?.()}),d=()=>{let e;if(r)return;let a=0===i?t.initialPromise:void 0;try{e=a??t.fn()}catch(t){e=Promise.reject(t)}Promise.resolve(e).then(l).catch(e=>{if(r)return;let a=t.retry??(o?0:3),u=t.retryDelay??P,l="function"==typeof u?u(i,e):u,p=!0===a||"number"==typeof a&&i<a||"function"==typeof a&&a(i,e);if(s||!p){c(e);return}i++,t.onFail?.(i,e),new Promise(t=>{setTimeout(t,l)}).then(()=>n()?void 0:h()).then(()=>{s?c(e):d()})})};return{promise:a,cancel:e=>{r||(c(new F(e)),t.abort?.())},continue:()=>(e?.(),a),cancelRetry:()=>{s=!0},continueRetry:()=>{s=!1},canStart:u,start:()=>(u()?d():h().then(d),a)}}var M=class{#r;destroy(){this.clearGcTimeout()}scheduleGc(){var t;this.clearGcTimeout(),"number"==typeof(t=this.gcTime)&&t>=0&&t!==1/0&&(this.#r=setTimeout(()=>{this.optionalRemove()},this.gcTime))}updateGcTime(t){this.gcTime=Math.max(this.gcTime||0,t??(o?1/0:3e5))}clearGcTimeout(){this.#r&&(clearTimeout(this.#r),this.#r=void 0)}},j=class extends M{#a;#n;#o;#u;#l;#c;constructor(t){super(),this.#c=!1,this.#l=t.defaultOptions,this.setOptions(t.options),this.observers=[],this.#o=t.cache,this.queryKey=t.queryKey,this.queryHash=t.queryHash,this.#a=function(t){let e="function"==typeof t.initialData?t.initialData():t.initialData,s=void 0!==e,i=s?"function"==typeof t.initialDataUpdatedAt?t.initialDataUpdatedAt():t.initialDataUpdatedAt:0;return{data:e,dataUpdateCount:0,dataUpdatedAt:s?i??Date.now():0,error:null,errorUpdateCount:0,errorUpdatedAt:0,fetchFailureCount:0,fetchFailureReason:null,fetchMeta:null,isInvalidated:!1,status:s?"success":"pending",fetchStatus:"idle"}}(this.options),this.state=t.state??this.#a,this.scheduleGc()}get meta(){return this.options.meta}get promise(){return this.#u?.promise}setOptions(t){this.options={...this.#l,...t},this.updateGcTime(this.options.gcTime)}optionalRemove(){this.observers.length||"idle"!==this.state.fetchStatus||this.#o.remove(this)}setData(t,e){var s,i;let r=(s=this.state.data,"function"==typeof(i=this.options).structuralSharing?i.structuralSharing(s,t):!1!==i.structuralSharing?function t(e,s){if(e===s)return e;let i=y(e)&&y(s);if(i||m(e)&&m(s)){let r=i?e:Object.keys(e),a=r.length,n=i?s:Object.keys(s),o=n.length,u=i?[]:{},l=0;for(let a=0;a<o;a++){let o=i?a:n[a];(!i&&r.includes(o)||i)&&void 0===e[o]&&void 0===s[o]?(u[o]=void 0,l++):(u[o]=t(e[o],s[o]),u[o]===e[o]&&void 0!==e[o]&&l++)}return a===o&&l===a?e:u}return s}(s,t):t);return this.#h({data:r,type:"success",dataUpdatedAt:e?.updatedAt,manual:e?.manual}),r}setState(t,e){this.#h({type:"setState",state:t,setStateOptions:e})}cancel(t){let e=this.#u?.promise;return this.#u?.cancel(t),e?e.then(u).catch(u):Promise.resolve()}destroy(){super.destroy(),this.cancel({silent:!0})}reset(){this.destroy(),this.setState(this.#a)}isActive(){return this.observers.some(t=>{var e;return!1!==("function"==typeof(e=t.options.enabled)?e(this):e)})}isDisabled(){return this.getObserversCount()>0?!this.isActive():this.options.queryFn===w||this.state.dataUpdateCount+this.state.errorUpdateCount===0}isStale(){return!!this.state.isInvalidated||(this.getObserversCount()>0?this.observers.some(t=>t.getCurrentResult().isStale):void 0===this.state.data)}isStaleByTime(t=0){return this.state.isInvalidated||void 0===this.state.data||!Math.max(this.state.dataUpdatedAt+(t||0)-Date.now(),0)}onFocus(){let t=this.observers.find(t=>t.shouldFetchOnWindowFocus());t?.refetch({cancelRefetch:!1}),this.#u?.continue()}onOnline(){let t=this.observers.find(t=>t.shouldFetchOnReconnect());t?.refetch({cancelRefetch:!1}),this.#u?.continue()}addObserver(t){this.observers.includes(t)||(this.observers.push(t),this.clearGcTimeout(),this.#o.notify({type:"observerAdded",query:this,observer:t}))}removeObserver(t){this.observers.includes(t)&&(this.observers=this.observers.filter(e=>e!==t),this.observers.length||(this.#u&&(this.#c?this.#u.cancel({revert:!0}):this.#u.cancelRetry()),this.scheduleGc()),this.#o.notify({type:"observerRemoved",query:this,observer:t}))}getObserversCount(){return this.observers.length}invalidate(){this.state.isInvalidated||this.#h({type:"invalidate"})}fetch(t,e){if("idle"!==this.state.fetchStatus){if(void 0!==this.state.data&&e?.cancelRefetch)this.cancel({silent:!0});else if(this.#u)return this.#u.continueRetry(),this.#u.promise}if(t&&this.setOptions(t),!this.options.queryFn){let t=this.observers.find(t=>t.options.queryFn);t&&this.setOptions(t.options)}let s=new AbortController,i=t=>{Object.defineProperty(t,"signal",{enumerable:!0,get:()=>(this.#c=!0,s.signal)})},r={fetchOptions:e,options:this.options,queryKey:this.queryKey,state:this.state,fetchFn:()=>{let t=C(this.options,e),s={queryKey:this.queryKey,meta:this.meta};return(i(s),this.#c=!1,this.options.persister)?this.options.persister(t,s,this):t(s)}};i(r),this.options.behavior?.onFetch(r,this),this.#n=this.state,("idle"===this.state.fetchStatus||this.state.fetchMeta!==r.fetchOptions?.meta)&&this.#h({type:"fetch",meta:r.fetchOptions?.meta});let a=t=>{D(t)&&t.silent||this.#h({type:"error",error:t}),D(t)||(this.#o.config.onError?.(t,this),this.#o.config.onSettled?.(this.state.data,t,this)),this.scheduleGc()};return this.#u=A({initialPromise:e?.initialPromise,fn:r.fetchFn,abort:s.abort.bind(s),onSuccess:t=>{if(void 0===t){a(Error(`${this.queryHash} data is undefined`));return}try{this.setData(t)}catch(t){a(t);return}this.#o.config.onSuccess?.(t,this),this.#o.config.onSettled?.(t,this.state.error,this),this.scheduleGc()},onError:a,onFail:(t,e)=>{this.#h({type:"failed",failureCount:t,error:e})},onPause:()=>{this.#h({type:"pause"})},onContinue:()=>{this.#h({type:"continue"})},retry:r.options.retry,retryDelay:r.options.retryDelay,networkMode:r.options.networkMode,canRun:()=>!0}),this.#u.start()}#h(t){this.state=(e=>{switch(t.type){case"failed":return{...e,fetchFailureCount:t.failureCount,fetchFailureReason:t.error};case"pause":return{...e,fetchStatus:"paused"};case"continue":return{...e,fetchStatus:"fetching"};case"fetch":var s;return{...e,...(s=e.data,{fetchFailureCount:0,fetchFailureReason:null,fetchStatus:S(this.options.networkMode)?"fetching":"paused",...void 0===s&&{error:null,status:"pending"}}),fetchMeta:t.meta??null};case"success":return{...e,data:t.data,dataUpdateCount:e.dataUpdateCount+1,dataUpdatedAt:t.dataUpdatedAt??Date.now(),error:null,isInvalidated:!1,status:"success",...!t.manual&&{fetchStatus:"idle",fetchFailureCount:0,fetchFailureReason:null}};case"error":let i=t.error;if(D(i)&&i.revert&&this.#n)return{...this.#n,fetchStatus:"idle"};return{...e,error:i,errorUpdateCount:e.errorUpdateCount+1,errorUpdatedAt:Date.now(),fetchFailureCount:e.fetchFailureCount+1,fetchFailureReason:i,fetchStatus:"idle",status:"error"};case"invalidate":return{...e,isInvalidated:!0};case"setState":return{...e,...t.state}}})(this.state),O.batch(()=>{this.observers.forEach(t=>{t.onQueryUpdate()}),this.#o.notify({query:this,type:"updated",action:t})})}},k=class extends x{constructor(t={}){super(),this.config=t,this.#d=new Map}#d;build(t,e,s){let i=e.queryKey,r=e.queryHash??d(i,e),a=this.get(r);return a||(a=new j({cache:this,queryKey:i,queryHash:r,options:t.defaultQueryOptions(e),state:s,defaultOptions:t.getQueryDefaults(i)}),this.add(a)),a}add(t){this.#d.has(t.queryHash)||(this.#d.set(t.queryHash,t),this.notify({type:"added",query:t}))}remove(t){let e=this.#d.get(t.queryHash);e&&(t.destroy(),e===t&&this.#d.delete(t.queryHash),this.notify({type:"removed",query:t}))}clear(){O.batch(()=>{this.getAll().forEach(t=>{this.remove(t)})})}get(t){return this.#d.get(t)}getAll(){return[...this.#d.values()]}find(t){let e={exact:!0,...t};return this.getAll().find(t=>c(e,t))}findAll(t={}){let e=this.getAll();return Object.keys(t).length>0?e.filter(e=>c(t,e)):e}notify(t){O.batch(()=>{this.listeners.forEach(e=>{e(t)})})}onFocus(){O.batch(()=>{this.getAll().forEach(t=>{t.onFocus()})})}onOnline(){O.batch(()=>{this.getAll().forEach(t=>{t.onOnline()})})}},Q=class extends M{#p;#f;#u;constructor(t){super(),this.mutationId=t.mutationId,this.#f=t.mutationCache,this.#p=[],this.state=t.state||{context:void 0,data:void 0,error:null,failureCount:0,failureReason:null,isPaused:!1,status:"idle",variables:void 0,submittedAt:0},this.setOptions(t.options),this.scheduleGc()}setOptions(t){this.options=t,this.updateGcTime(this.options.gcTime)}get meta(){return this.options.meta}addObserver(t){this.#p.includes(t)||(this.#p.push(t),this.clearGcTimeout(),this.#f.notify({type:"observerAdded",mutation:this,observer:t}))}removeObserver(t){this.#p=this.#p.filter(e=>e!==t),this.scheduleGc(),this.#f.notify({type:"observerRemoved",mutation:this,observer:t})}optionalRemove(){this.#p.length||("pending"===this.state.status?this.scheduleGc():this.#f.remove(this))}continue(){return this.#u?.continue()??this.execute(this.state.variables)}async execute(t){this.#u=A({fn:()=>this.options.mutationFn?this.options.mutationFn(t):Promise.reject(Error("No mutationFn found")),onFail:(t,e)=>{this.#h({type:"failed",failureCount:t,error:e})},onPause:()=>{this.#h({type:"pause"})},onContinue:()=>{this.#h({type:"continue"})},retry:this.options.retry??0,retryDelay:this.options.retryDelay,networkMode:this.options.networkMode,canRun:()=>this.#f.canRun(this)});let e="pending"===this.state.status,s=!this.#u.canStart();try{if(!e){this.#h({type:"pending",variables:t,isPaused:s}),await this.#f.config.onMutate?.(t,this);let e=await this.options.onMutate?.(t);e!==this.state.context&&this.#h({type:"pending",context:e,variables:t,isPaused:s})}let i=await this.#u.start();return await this.#f.config.onSuccess?.(i,t,this.state.context,this),await this.options.onSuccess?.(i,t,this.state.context),await this.#f.config.onSettled?.(i,null,this.state.variables,this.state.context,this),await this.options.onSettled?.(i,null,t,this.state.context),this.#h({type:"success",data:i}),i}catch(e){try{throw await this.#f.config.onError?.(e,t,this.state.context,this),await this.options.onError?.(e,t,this.state.context),await this.#f.config.onSettled?.(void 0,e,this.state.variables,this.state.context,this),await this.options.onSettled?.(void 0,e,t,this.state.context),e}finally{this.#h({type:"error",error:e})}}finally{this.#f.runNext(this)}}#h(t){this.state=(e=>{switch(t.type){case"failed":return{...e,failureCount:t.failureCount,failureReason:t.error};case"pause":return{...e,isPaused:!0};case"continue":return{...e,isPaused:!1};case"pending":return{...e,context:t.context,data:void 0,failureCount:0,failureReason:null,error:null,isPaused:t.isPaused,status:"pending",variables:t.variables,submittedAt:Date.now()};case"success":return{...e,data:t.data,failureCount:0,failureReason:null,error:null,status:"success",isPaused:!1};case"error":return{...e,data:void 0,error:t.error,failureCount:e.failureCount+1,failureReason:t.error,isPaused:!1,status:"error"}}})(this.state),O.batch(()=>{this.#p.forEach(e=>{e.onMutationUpdate(t)}),this.#f.notify({mutation:this,type:"updated",action:t})})}},T=class extends x{constructor(t={}){super(),this.config=t,this.#y=new Map,this.#m=Date.now()}#y;#m;build(t,e,s){let i=new Q({mutationCache:this,mutationId:++this.#m,options:t.defaultMutationOptions(e),state:s});return this.add(i),i}add(t){let e=R(t),s=this.#y.get(e)??[];s.push(t),this.#y.set(e,s),this.notify({type:"added",mutation:t})}remove(t){let e=R(t);if(this.#y.has(e)){let s=this.#y.get(e)?.filter(e=>e!==t);s&&(0===s.length?this.#y.delete(e):this.#y.set(e,s))}this.notify({type:"removed",mutation:t})}canRun(t){let e=this.#y.get(R(t))?.find(t=>"pending"===t.state.status);return!e||e===t}runNext(t){let e=this.#y.get(R(t))?.find(e=>e!==t&&e.state.isPaused);return e?.continue()??Promise.resolve()}clear(){O.batch(()=>{this.getAll().forEach(t=>{this.remove(t)})})}getAll(){return[...this.#y.values()].flat()}find(t){let e={exact:!0,...t};return this.getAll().find(t=>h(e,t))}findAll(t={}){return this.getAll().filter(e=>h(t,e))}notify(t){O.batch(()=>{this.listeners.forEach(e=>{e(t)})})}resumePausedMutations(){let t=this.getAll().filter(t=>t.state.isPaused);return O.batch(()=>Promise.all(t.map(t=>t.continue().catch(u))))}};function R(t){return t.options.scope?.id??String(t.mutationId)}function U(t){return{onFetch:(e,s)=>{let i=e.options,r=e.fetchOptions?.meta?.fetchMore?.direction,a=e.state.data?.pages||[],n=e.state.data?.pageParams||[],o={pages:[],pageParams:[]},u=0,l=async()=>{let s=!1,l=t=>{Object.defineProperty(t,"signal",{enumerable:!0,get:()=>(e.signal.aborted?s=!0:e.signal.addEventListener("abort",()=>{s=!0}),e.signal)})},c=C(e.options,e.fetchOptions),h=async(t,i,r)=>{if(s)return Promise.reject();if(null==i&&t.pages.length)return Promise.resolve(t);let a={queryKey:e.queryKey,pageParam:i,direction:r?"backward":"forward",meta:e.options.meta};l(a);let n=await c(a),{maxPages:o}=e.options,u=r?v:b;return{pages:u(t.pages,n,o),pageParams:u(t.pageParams,i,o)}};if(r&&a.length){let t="backward"===r,e={pages:a,pageParams:n},s=(t?function(t,{pages:e,pageParams:s}){return e.length>0?t.getPreviousPageParam?.(e[0],e,s[0],s):void 0}:I)(i,e);o=await h(e,s,t)}else{let e=t??a.length;do{let t=0===u?n[0]??i.initialPageParam:I(i,o);if(u>0&&null==t)break;o=await h(o,t),u++}while(u<e)}return o};e.options.persister?e.fetchFn=()=>e.options.persister?.(l,{queryKey:e.queryKey,meta:e.options.meta,signal:e.signal},s):e.fetchFn=l}}}function I(t,{pages:e,pageParams:s}){let i=e.length-1;return e.length>0?t.getNextPageParam(e[i],e,s[i],s):void 0}var K=class{#g;#f;#l;#b;#v;#w;#C;#O;constructor(t={}){this.#g=t.queryCache||new k,this.#f=t.mutationCache||new T,this.#l=t.defaultOptions||{},this.#b=new Map,this.#v=new Map,this.#w=0}mount(){this.#w++,1===this.#w&&(this.#C=q.subscribe(async t=>{t&&(await this.resumePausedMutations(),this.#g.onFocus())}),this.#O=E.subscribe(async t=>{t&&(await this.resumePausedMutations(),this.#g.onOnline())}))}unmount(){this.#w--,0===this.#w&&(this.#C?.(),this.#C=void 0,this.#O?.(),this.#O=void 0)}isFetching(t){return this.#g.findAll({...t,fetchStatus:"fetching"}).length}isMutating(t){return this.#f.findAll({...t,status:"pending"}).length}getQueryData(t){let e=this.defaultQueryOptions({queryKey:t});return this.#g.get(e.queryHash)?.state.data}ensureQueryData(t){let e=this.getQueryData(t.queryKey);if(void 0===e)return this.fetchQuery(t);{let s=this.defaultQueryOptions(t),i=this.#g.build(this,s);return t.revalidateIfStale&&i.isStaleByTime(l(s.staleTime,i))&&this.prefetchQuery(s),Promise.resolve(e)}}getQueriesData(t){return this.#g.findAll(t).map(({queryKey:t,state:e})=>[t,e.data])}setQueryData(t,e,s){let i=this.defaultQueryOptions({queryKey:t}),r=this.#g.get(i.queryHash),a=r?.state.data,n="function"==typeof e?e(a):e;if(void 0!==n)return this.#g.build(this,i).setData(n,{...s,manual:!0})}setQueriesData(t,e,s){return O.batch(()=>this.#g.findAll(t).map(({queryKey:t})=>[t,this.setQueryData(t,e,s)]))}getQueryState(t){let e=this.defaultQueryOptions({queryKey:t});return this.#g.get(e.queryHash)?.state}removeQueries(t){let e=this.#g;O.batch(()=>{e.findAll(t).forEach(t=>{e.remove(t)})})}resetQueries(t,e){let s=this.#g,i={type:"active",...t};return O.batch(()=>(s.findAll(t).forEach(t=>{t.reset()}),this.refetchQueries(i,e)))}cancelQueries(t={},e={}){let s={revert:!0,...e};return Promise.all(O.batch(()=>this.#g.findAll(t).map(t=>t.cancel(s)))).then(u).catch(u)}invalidateQueries(t={},e={}){return O.batch(()=>{if(this.#g.findAll(t).forEach(t=>{t.invalidate()}),"none"===t.refetchType)return Promise.resolve();let s={...t,type:t.refetchType??t.type??"active"};return this.refetchQueries(s,e)})}refetchQueries(t={},e){let s={...e,cancelRefetch:e?.cancelRefetch??!0};return Promise.all(O.batch(()=>this.#g.findAll(t).filter(t=>!t.isDisabled()).map(t=>{let e=t.fetch(void 0,s);return s.throwOnError||(e=e.catch(u)),"paused"===t.state.fetchStatus?Promise.resolve():e}))).then(u)}fetchQuery(t){let e=this.defaultQueryOptions(t);void 0===e.retry&&(e.retry=!1);let s=this.#g.build(this,e);return s.isStaleByTime(l(e.staleTime,s))?s.fetch(e):Promise.resolve(s.state.data)}prefetchQuery(t){return this.fetchQuery(t).then(u).catch(u)}fetchInfiniteQuery(t){return t.behavior=U(t.pages),this.fetchQuery(t)}prefetchInfiniteQuery(t){return this.fetchInfiniteQuery(t).then(u).catch(u)}ensureInfiniteQueryData(t){return t.behavior=U(t.pages),this.ensureQueryData(t)}resumePausedMutations(){return E.isOnline()?this.#f.resumePausedMutations():Promise.resolve()}getQueryCache(){return this.#g}getMutationCache(){return this.#f}getDefaultOptions(){return this.#l}setDefaultOptions(t){this.#l=t}setQueryDefaults(t,e){this.#b.set(p(t),{queryKey:t,defaultOptions:e})}getQueryDefaults(t){let e=[...this.#b.values()],s={};return e.forEach(e=>{f(t,e.queryKey)&&(s={...s,...e.defaultOptions})}),s}setMutationDefaults(t,e){this.#v.set(p(t),{mutationKey:t,defaultOptions:e})}getMutationDefaults(t){let e=[...this.#v.values()],s={};return e.forEach(e=>{f(t,e.mutationKey)&&(s={...s,...e.defaultOptions})}),s}defaultQueryOptions(t){if(t._defaulted)return t;let e={...this.#l.queries,...this.getQueryDefaults(t.queryKey),...t,_defaulted:!0};return e.queryHash||(e.queryHash=d(e.queryKey,e)),void 0===e.refetchOnReconnect&&(e.refetchOnReconnect="always"!==e.networkMode),void 0===e.throwOnError&&(e.throwOnError=!!e.suspense),!e.networkMode&&e.persister&&(e.networkMode="offlineFirst"),!0!==e.enabled&&e.queryFn===w&&(e.enabled=!1),e}defaultMutationOptions(t){return t?._defaulted?t:{...this.#l.mutations,...t?.mutationKey&&this.getMutationDefaults(t.mutationKey),...t,_defaulted:!0}}clear(){this.#g.clear(),this.#f.clear()}},N=s(7294),H=N.createContext(void 0),$=({client:t,children:e})=>(N.useEffect(()=>(t.mount(),()=>{t.unmount()}),[t]),(0,n.jsx)(H.Provider,{value:t,children:e}));let L={data:""},_=t=>"object"==typeof window?((t?t.querySelector("#_goober"):window._goober)||Object.assign((t||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:t||L,G=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,z=/\/\*[^]*?\*\/|  +/g,B=/\n+/g,X=(t,e)=>{let s="",i="",r="";for(let a in t){let n=t[a];"@"==a[0]?"i"==a[1]?s=a+" "+n+";":i+="f"==a[1]?X(n,a):a+"{"+X(n,"k"==a[1]?"":e)+"}":"object"==typeof n?i+=X(n,e?e.replace(/([^,])+/g,t=>a.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,e=>/&/.test(e)?e.replace(/&/g,t):t?t+" "+e:e)):a):null!=n&&(a=/^--/.test(a)?a:a.replace(/[A-Z]/g,"-$&").toLowerCase(),r+=X.p?X.p(a,n):a+":"+n+";")}return s+(e&&r?e+"{"+r+"}":r)+i},J={},W=t=>{if("object"==typeof t){let e="";for(let s in t)e+=s+W(t[s]);return e}return t},Y=(t,e,s,i,r)=>{var a;let n=W(t),o=J[n]||(J[n]=(t=>{let e=0,s=11;for(;e<t.length;)s=101*s+t.charCodeAt(e++)>>>0;return"go"+s})(n));if(!J[o]){let e=n!==t?t:(t=>{let e,s,i=[{}];for(;e=G.exec(t.replace(z,""));)e[4]?i.shift():e[3]?(s=e[3].replace(B," ").trim(),i.unshift(i[0][s]=i[0][s]||{})):i[0][e[1]]=e[2].replace(B," ").trim();return i[0]})(t);J[o]=X(r?{["@keyframes "+o]:e}:e,s?"":"."+o)}let u=s&&J.g?J.g:null;return s&&(J.g=J[o]),a=J[o],u?e.data=e.data.replace(u,a):-1===e.data.indexOf(a)&&(e.data=i?a+e.data:e.data+a),o},Z=(t,e,s)=>t.reduce((t,i,r)=>{let a=e[r];if(a&&a.call){let t=a(s),e=t&&t.props&&t.props.className||/^go/.test(t)&&t;a=e?"."+e:t&&"object"==typeof t?t.props?"":X(t,""):!1===t?"":t}return t+i+(null==a?"":a)},"");function V(t){let e=this||{},s=t.call?t(e.p):t;return Y(s.unshift?s.raw?Z(s,[].slice.call(arguments,1),e.p):s.reduce((t,s)=>Object.assign(t,s&&s.call?s(e.p):s),{}):s,_(e.target),e.g,e.o,e.k)}V.bind({g:1});let tt,te,ts,ti=V.bind({k:1});function tr(t,e){let s=this||{};return function(){let i=arguments;function r(a,n){let o=Object.assign({},a),u=o.className||r.className;s.p=Object.assign({theme:te&&te()},o),s.o=/ *go\d+/.test(u),o.className=V.apply(s,i)+(u?" "+u:""),e&&(o.ref=n);let l=t;return t[0]&&(l=o.as||t,delete o.as),ts&&l[0]&&ts(o),tt(l,o)}return e?e(r):r}}var ta=t=>"function"==typeof t,tn=(t,e)=>ta(t)?t(e):t,to=(i=0,()=>(++i).toString()),tu=()=>{if(void 0===r&&"u">typeof window){let t=matchMedia("(prefers-reduced-motion: reduce)");r=!t||t.matches}return r},tl=new Map,tc=t=>{if(tl.has(t))return;let e=setTimeout(()=>{tl.delete(t),ty({type:4,toastId:t})},1e3);tl.set(t,e)},th=t=>{let e=tl.get(t);e&&clearTimeout(e)},td=(t,e)=>{switch(e.type){case 0:return{...t,toasts:[e.toast,...t.toasts].slice(0,20)};case 1:return e.toast.id&&th(e.toast.id),{...t,toasts:t.toasts.map(t=>t.id===e.toast.id?{...t,...e.toast}:t)};case 2:let{toast:s}=e;return t.toasts.find(t=>t.id===s.id)?td(t,{type:1,toast:s}):td(t,{type:0,toast:s});case 3:let{toastId:i}=e;return i?tc(i):t.toasts.forEach(t=>{tc(t.id)}),{...t,toasts:t.toasts.map(t=>t.id===i||void 0===i?{...t,visible:!1}:t)};case 4:return void 0===e.toastId?{...t,toasts:[]}:{...t,toasts:t.toasts.filter(t=>t.id!==e.toastId)};case 5:return{...t,pausedAt:e.time};case 6:let r=e.time-(t.pausedAt||0);return{...t,pausedAt:void 0,toasts:t.toasts.map(t=>({...t,pauseDuration:t.pauseDuration+r}))}}},tp=[],tf={toasts:[],pausedAt:void 0},ty=t=>{tf=td(tf,t),tp.forEach(t=>{t(tf)})},tm={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},tg=(t={})=>{let[e,s]=(0,N.useState)(tf);(0,N.useEffect)(()=>(tp.push(s),()=>{let t=tp.indexOf(s);t>-1&&tp.splice(t,1)}),[e]);let i=e.toasts.map(e=>{var s,i;return{...t,...t[e.type],...e,duration:e.duration||(null==(s=t[e.type])?void 0:s.duration)||(null==t?void 0:t.duration)||tm[e.type],style:{...t.style,...null==(i=t[e.type])?void 0:i.style,...e.style}}});return{...e,toasts:i}},tb=(t,e="blank",s)=>({createdAt:Date.now(),visible:!0,type:e,ariaProps:{role:"status","aria-live":"polite"},message:t,pauseDuration:0,...s,id:(null==s?void 0:s.id)||to()}),tv=t=>(e,s)=>{let i=tb(e,t,s);return ty({type:2,toast:i}),i.id},tw=(t,e)=>tv("blank")(t,e);tw.error=tv("error"),tw.success=tv("success"),tw.loading=tv("loading"),tw.custom=tv("custom"),tw.dismiss=t=>{ty({type:3,toastId:t})},tw.remove=t=>ty({type:4,toastId:t}),tw.promise=(t,e,s)=>{let i=tw.loading(e.loading,{...s,...null==s?void 0:s.loading});return t.then(t=>(tw.success(tn(e.success,t),{id:i,...s,...null==s?void 0:s.success}),t)).catch(t=>{tw.error(tn(e.error,t),{id:i,...s,...null==s?void 0:s.error})}),t};var tC=(t,e)=>{ty({type:1,toast:{id:t,height:e}})},tO=()=>{ty({type:5,time:Date.now()})},tx=t=>{let{toasts:e,pausedAt:s}=tg(t);(0,N.useEffect)(()=>{if(s)return;let t=Date.now(),i=e.map(e=>{if(e.duration===1/0)return;let s=(e.duration||0)+e.pauseDuration-(t-e.createdAt);if(s<0){e.visible&&tw.dismiss(e.id);return}return setTimeout(()=>tw.dismiss(e.id),s)});return()=>{i.forEach(t=>t&&clearTimeout(t))}},[e,s]);let i=(0,N.useCallback)(()=>{s&&ty({type:6,time:Date.now()})},[s]),r=(0,N.useCallback)((t,s)=>{let{reverseOrder:i=!1,gutter:r=8,defaultPosition:a}=s||{},n=e.filter(e=>(e.position||a)===(t.position||a)&&e.height),o=n.findIndex(e=>e.id===t.id),u=n.filter((t,e)=>e<o&&t.visible).length;return n.filter(t=>t.visible).slice(...i?[u+1]:[0,u]).reduce((t,e)=>t+(e.height||0)+r,0)},[e]);return{toasts:e,handlers:{updateHeight:tC,startPause:tO,endPause:i,calculateOffset:r}}},tq=ti`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,tE=ti`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,tP=ti`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,tS=tr("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${t=>t.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${tq} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${tE} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${t=>t.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${tP} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,tF=ti`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,tD=tr("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${t=>t.secondary||"#e0e0e0"};
  border-right-color: ${t=>t.primary||"#616161"};
  animation: ${tF} 1s linear infinite;
`,tA=ti`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,tM=ti`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,tj=tr("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${t=>t.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${tA} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${tM} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${t=>t.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,tk=tr("div")`
  position: absolute;
`,tQ=tr("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,tT=ti`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,tR=tr("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${tT} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,tU=({toast:t})=>{let{icon:e,type:s,iconTheme:i}=t;return void 0!==e?"string"==typeof e?N.createElement(tR,null,e):e:"blank"===s?null:N.createElement(tQ,null,N.createElement(tD,{...i}),"loading"!==s&&N.createElement(tk,null,"error"===s?N.createElement(tS,{...i}):N.createElement(tj,{...i})))},tI=t=>`
0% {transform: translate3d(0,${-200*t}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,tK=t=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*t}%,-1px) scale(.6); opacity:0;}
`,tN=tr("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,tH=tr("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,t$=(t,e)=>{let s=t.includes("top")?1:-1,[i,r]=tu()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[tI(s),tK(s)];return{animation:e?`${ti(i)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${ti(r)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},tL=N.memo(({toast:t,position:e,style:s,children:i})=>{let r=t.height?t$(t.position||e||"top-center",t.visible):{opacity:0},a=N.createElement(tU,{toast:t}),n=N.createElement(tH,{...t.ariaProps},tn(t.message,t));return N.createElement(tN,{className:t.className,style:{...r,...s,...t.style}},"function"==typeof i?i({icon:a,message:n}):N.createElement(N.Fragment,null,a,n))});a=N.createElement,X.p=void 0,tt=a,te=void 0,ts=void 0;var t_=({id:t,className:e,style:s,onHeightUpdate:i,children:r})=>{let a=N.useCallback(e=>{if(e){let s=()=>{i(t,e.getBoundingClientRect().height)};s(),new MutationObserver(s).observe(e,{subtree:!0,childList:!0,characterData:!0})}},[t,i]);return N.createElement("div",{ref:a,className:e,style:s},r)},tG=(t,e)=>{let s=t.includes("top"),i=t.includes("center")?{justifyContent:"center"}:t.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:tu()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${e*(s?1:-1)}px)`,...s?{top:0}:{bottom:0},...i}},tz=V`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,tB=({reverseOrder:t,position:e="top-center",toastOptions:s,gutter:i,children:r,containerStyle:a,containerClassName:n})=>{let{toasts:o,handlers:u}=tx(s);return N.createElement("div",{style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...a},className:n,onMouseEnter:u.startPause,onMouseLeave:u.endPause},o.map(s=>{let a=s.position||e,n=tG(a,u.calculateOffset(s,{reverseOrder:t,gutter:i,defaultPosition:e}));return N.createElement(t_,{id:s.id,key:s.id,onHeightUpdate:u.updateHeight,className:s.visible?tz:"",style:n},"custom"===s.type?tn(s.message,s):r?r(s):N.createElement(tL,{toast:s,position:a}))}))};s(3434);let tX=new K;var tJ=function(t){let{Component:e,pageProps:s}=t;return(0,n.jsxs)($,{client:tX,children:[(0,n.jsx)(tB,{}),(0,n.jsx)(e,{...s})]})}},3434:function(){}},function(t){var e=function(e){return t(t.s=e)};t.O(0,[774,179],function(){return e(1118),e(3079)}),_N_E=t.O()}]);